package com.sjprogramming.empapp;

public interface EmployeeDaoIntrf {

    //create employee

    public void createEmployee(Employee emp);
    //show all employees
    public void showAllEmployee();
    //show employee based on id
    public void showEmployeeBasedOnId(int id);
    //upadte the employee
    public void updateEmployee(int id,String name);
    //delete the employee
    public void deleteEmployee(int id);
}
